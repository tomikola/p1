﻿using System.Windows.Forms;

namespace project1_Mikolajczyk65815
{
    partial class new_data_types
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tmtabs = new System.Windows.Forms.TabControl();
            this.tmtab_page_cockpit = new System.Windows.Forms.TabPage();
            this.tmcocpitlabel = new System.Windows.Forms.Label();
            this.tmtab_page_matrix = new System.Windows.Forms.TabPage();
            this.tmgroupBox2 = new System.Windows.Forms.GroupBox();
            this.tmbtm_reset = new System.Windows.Forms.Button();
            this.tmbtm_accept_matrix_b_elements = new System.Windows.Forms.Button();
            this.tmbtm_generate_matrix_b_elements = new System.Windows.Forms.Button();
            this.tmbtm_create_gridview_matrix_b = new System.Windows.Forms.Button();
            this.tmbtm_accept_matrix_a_elements = new System.Windows.Forms.Button();
            this.tmbtm_generate_matrix_a_elements = new System.Windows.Forms.Button();
            this.tmbtm_create_gridview_matrix_a = new System.Windows.Forms.Button();
            this.tmgroupBox1 = new System.Windows.Forms.GroupBox();
            this.tmbtm_multiply = new System.Windows.Forms.Button();
            this.tmbtm_addition = new System.Windows.Forms.Button();
            this.tmbtm_subtraction = new System.Windows.Forms.Button();
            this.tmtextbox_number_of_columns = new System.Windows.Forms.TextBox();
            this.tmlabel3 = new System.Windows.Forms.Label();
            this.tmlabel2 = new System.Windows.Forms.Label();
            this.tmtextbox_number_of_rows = new System.Windows.Forms.TextBox();
            this.tmtab_page_complex_number = new System.Windows.Forms.TabPage();
            this.tmtextbox_result = new System.Windows.Forms.TextBox();
            this.tmlabel50 = new System.Windows.Forms.Label();
            this.tmgroupbox_cn2 = new System.Windows.Forms.GroupBox();
            this.tmtextbox_real_a = new System.Windows.Forms.TextBox();
            this.tmtextbox_imagine_a = new System.Windows.Forms.TextBox();
            this.tmlabel_cn_4 = new System.Windows.Forms.Label();
            this.tmtextbox_real_b = new System.Windows.Forms.TextBox();
            this.tmlabel_cn_3 = new System.Windows.Forms.Label();
            this.tmtextbox_imagine_b = new System.Windows.Forms.TextBox();
            this.tmlabel_cn_2 = new System.Windows.Forms.Label();
            this.tmtextbox_real_c = new System.Windows.Forms.TextBox();
            this.tmlabel_cn_1 = new System.Windows.Forms.Label();
            this.tmtextbox_imagine_c = new System.Windows.Forms.TextBox();
            this.tmlabel_cn_6 = new System.Windows.Forms.Label();
            this.tmtextbox_real_e = new System.Windows.Forms.TextBox();
            this.tmlabel_cn_5 = new System.Windows.Forms.Label();
            this.tmtextbox_imagine_e = new System.Windows.Forms.TextBox();
            this.tmgroupbox_cn = new System.Windows.Forms.GroupBox();
            this.tmbtm_cn_add = new System.Windows.Forms.Button();
            this.tmlabel5 = new System.Windows.Forms.Label();
            this.tmmatrix_a_grid = new System.Windows.Forms.DataGridView();
            this.tmmatrix_b_grid = new System.Windows.Forms.DataGridView();
            this.tmmatrix_c_grid = new System.Windows.Forms.DataGridView();
            this.tmerrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.tmtabs.SuspendLayout();
            this.tmtab_page_cockpit.SuspendLayout();
            this.tmtab_page_matrix.SuspendLayout();
            this.tmgroupBox2.SuspendLayout();
            this.tmgroupBox1.SuspendLayout();
            this.tmtab_page_complex_number.SuspendLayout();
            this.tmgroupbox_cn2.SuspendLayout();
            this.tmgroupbox_cn.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tmmatrix_a_grid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmmatrix_b_grid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmmatrix_c_grid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmerrorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // tmtabs
            // 
            this.tmtabs.Controls.Add(this.tmtab_page_cockpit);
            this.tmtabs.Controls.Add(this.tmtab_page_matrix);
            this.tmtabs.Controls.Add(this.tmtab_page_complex_number);
            this.tmtabs.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tmtabs.Location = new System.Drawing.Point(0, 0);
            this.tmtabs.Name = "tmtabs";
            this.tmtabs.SelectedIndex = 0;
            this.tmtabs.Size = new System.Drawing.Size(1150, 1000);
            this.tmtabs.TabIndex = 0;
            this.tmtabs.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tmtabControl_Selecting);
            // 
            // tmtab_page_cockpit
            // 
            this.tmtab_page_cockpit.BackColor = System.Drawing.Color.IndianRed;
            this.tmtab_page_cockpit.Controls.Add(this.tmcocpitlabel);
            this.tmtab_page_cockpit.Location = new System.Drawing.Point(4, 24);
            this.tmtab_page_cockpit.Name = "tmtab_page_cockpit";
            this.tmtab_page_cockpit.Padding = new System.Windows.Forms.Padding(3);
            this.tmtab_page_cockpit.Size = new System.Drawing.Size(1142, 972);
            this.tmtab_page_cockpit.TabIndex = 0;
            this.tmtab_page_cockpit.Text = "Cockpit";
            // 
            // tmcocpitlabel
            // 
            this.tmcocpitlabel.AutoSize = true;
            this.tmcocpitlabel.Font = new System.Drawing.Font("Arial Narrow", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tmcocpitlabel.Location = new System.Drawing.Point(53, 175);
            this.tmcocpitlabel.Name = "tmcocpitlabel";
            this.tmcocpitlabel.Size = new System.Drawing.Size(1042, 114);
            this.tmcocpitlabel.TabIndex = 0;
            this.tmcocpitlabel.Text = "Overloading operators and methods \n and extending the method list for already exi" +
    "sting classes";
            this.tmcocpitlabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tmtab_page_matrix
            // 
            this.tmtab_page_matrix.BackColor = System.Drawing.Color.LightGray;
            this.tmtab_page_matrix.Controls.Add(this.tmgroupBox2);
            this.tmtab_page_matrix.Controls.Add(this.tmgroupBox1);
            this.tmtab_page_matrix.Controls.Add(this.tmtextbox_number_of_columns);
            this.tmtab_page_matrix.Controls.Add(this.tmlabel3);
            this.tmtab_page_matrix.Controls.Add(this.tmlabel2);
            this.tmtab_page_matrix.Controls.Add(this.tmtextbox_number_of_rows);
            this.tmtab_page_matrix.Font = new System.Drawing.Font("Arial Narrow", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tmtab_page_matrix.Location = new System.Drawing.Point(4, 24);
            this.tmtab_page_matrix.Name = "tmtab_page_matrix";
            this.tmtab_page_matrix.Padding = new System.Windows.Forms.Padding(3);
            this.tmtab_page_matrix.Size = new System.Drawing.Size(1142, 972);
            this.tmtab_page_matrix.TabIndex = 1;
            this.tmtab_page_matrix.Text = "Operations on Matrices";
            // 
            // tmgroupBox2
            // 
            this.tmgroupBox2.Controls.Add(this.tmbtm_reset);
            this.tmgroupBox2.Controls.Add(this.tmbtm_accept_matrix_b_elements);
            this.tmgroupBox2.Controls.Add(this.tmbtm_generate_matrix_b_elements);
            this.tmgroupBox2.Controls.Add(this.tmbtm_create_gridview_matrix_b);
            this.tmgroupBox2.Controls.Add(this.tmbtm_accept_matrix_a_elements);
            this.tmgroupBox2.Controls.Add(this.tmbtm_generate_matrix_a_elements);
            this.tmgroupBox2.Controls.Add(this.tmbtm_create_gridview_matrix_a);
            this.tmgroupBox2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(239)));
            this.tmgroupBox2.Location = new System.Drawing.Point(837, 14);
            this.tmgroupBox2.Name = "tmgroupBox2";
            this.tmgroupBox2.Size = new System.Drawing.Size(281, 450);
            this.tmgroupBox2.TabIndex = 6;
            this.tmgroupBox2.TabStop = false;
            this.tmgroupBox2.Text = "Additional functional buttons";
            // 
            // tmbtm_reset
            // 
            this.tmbtm_reset.BackColor = System.Drawing.Color.RosyBrown;
            this.tmbtm_reset.Location = new System.Drawing.Point(7, 388);
            this.tmbtm_reset.Name = "tmbtm_reset";
            this.tmbtm_reset.Size = new System.Drawing.Size(200, 50);
            this.tmbtm_reset.TabIndex = 6;
            this.tmbtm_reset.Text = "Reset";
            this.tmbtm_reset.UseVisualStyleBackColor = false;
            // 
            // tmbtm_accept_matrix_b_elements
            // 
            this.tmbtm_accept_matrix_b_elements.BackColor = System.Drawing.Color.RosyBrown;
            this.tmbtm_accept_matrix_b_elements.Location = new System.Drawing.Point(6, 330);
            this.tmbtm_accept_matrix_b_elements.Name = "tmbtm_accept_matrix_b_elements";
            this.tmbtm_accept_matrix_b_elements.Size = new System.Drawing.Size(200, 50);
            this.tmbtm_accept_matrix_b_elements.TabIndex = 5;
            this.tmbtm_accept_matrix_b_elements.Text = "Accept matrix B elements";
            this.tmbtm_accept_matrix_b_elements.UseVisualStyleBackColor = false;
            this.tmbtm_accept_matrix_b_elements.Click += new System.EventHandler(this.tmbtm_accept_matrix_b_elements_Click);
            // 
            // tmbtm_generate_matrix_b_elements
            // 
            this.tmbtm_generate_matrix_b_elements.BackColor = System.Drawing.Color.RosyBrown;
            this.tmbtm_generate_matrix_b_elements.Location = new System.Drawing.Point(7, 274);
            this.tmbtm_generate_matrix_b_elements.Name = "tmbtm_generate_matrix_b_elements";
            this.tmbtm_generate_matrix_b_elements.Size = new System.Drawing.Size(200, 50);
            this.tmbtm_generate_matrix_b_elements.TabIndex = 4;
            this.tmbtm_generate_matrix_b_elements.Text = "Generate matrix B elements";
            this.tmbtm_generate_matrix_b_elements.UseVisualStyleBackColor = false;
            this.tmbtm_generate_matrix_b_elements.Click += new System.EventHandler(this.tmbtm_generate_matrix_b_elements_Click);
            // 
            // tmbtm_create_gridview_matrix_b
            // 
            this.tmbtm_create_gridview_matrix_b.BackColor = System.Drawing.Color.RosyBrown;
            this.tmbtm_create_gridview_matrix_b.Location = new System.Drawing.Point(7, 211);
            this.tmbtm_create_gridview_matrix_b.Name = "tmbtm_create_gridview_matrix_b";
            this.tmbtm_create_gridview_matrix_b.Size = new System.Drawing.Size(200, 50);
            this.tmbtm_create_gridview_matrix_b.TabIndex = 3;
            this.tmbtm_create_gridview_matrix_b.Text = "Create GridView Matrix B\r\n";
            this.tmbtm_create_gridview_matrix_b.UseVisualStyleBackColor = false;
            this.tmbtm_create_gridview_matrix_b.Click += new System.EventHandler(this.tmbtm_create_gridview_matrix_b_Click);
            // 
            // tmbtm_accept_matrix_a_elements
            // 
            this.tmbtm_accept_matrix_a_elements.BackColor = System.Drawing.Color.RosyBrown;
            this.tmbtm_accept_matrix_a_elements.Location = new System.Drawing.Point(7, 153);
            this.tmbtm_accept_matrix_a_elements.Name = "tmbtm_accept_matrix_a_elements";
            this.tmbtm_accept_matrix_a_elements.Size = new System.Drawing.Size(200, 50);
            this.tmbtm_accept_matrix_a_elements.TabIndex = 2;
            this.tmbtm_accept_matrix_a_elements.Text = "Accept matrix A elements";
            this.tmbtm_accept_matrix_a_elements.UseVisualStyleBackColor = false;
            this.tmbtm_accept_matrix_a_elements.Click += new System.EventHandler(this.tmbtm_accept_matrix_a_elements_Click);
            // 
            // tmbtm_generate_matrix_a_elements
            // 
            this.tmbtm_generate_matrix_a_elements.BackColor = System.Drawing.Color.RosyBrown;
            this.tmbtm_generate_matrix_a_elements.Location = new System.Drawing.Point(7, 95);
            this.tmbtm_generate_matrix_a_elements.Name = "tmbtm_generate_matrix_a_elements";
            this.tmbtm_generate_matrix_a_elements.Size = new System.Drawing.Size(200, 50);
            this.tmbtm_generate_matrix_a_elements.TabIndex = 1;
            this.tmbtm_generate_matrix_a_elements.Text = "Generate matrix A elements";
            this.tmbtm_generate_matrix_a_elements.UseVisualStyleBackColor = false;
            this.tmbtm_generate_matrix_a_elements.Click += new System.EventHandler(this.tmbtm_generate_matrix_a_elements_Click);
            // 
            // tmbtm_create_gridview_matrix_a
            // 
            this.tmbtm_create_gridview_matrix_a.BackColor = System.Drawing.Color.RosyBrown;
            this.tmbtm_create_gridview_matrix_a.Location = new System.Drawing.Point(7, 32);
            this.tmbtm_create_gridview_matrix_a.Name = "tmbtm_create_gridview_matrix_a";
            this.tmbtm_create_gridview_matrix_a.Size = new System.Drawing.Size(200, 50);
            this.tmbtm_create_gridview_matrix_a.TabIndex = 0;
            this.tmbtm_create_gridview_matrix_a.Text = "Create GridView Matrix A";
            this.tmbtm_create_gridview_matrix_a.UseVisualStyleBackColor = false;
            this.tmbtm_create_gridview_matrix_a.Click += new System.EventHandler(this.tmbtm_create_gridview_matrix_a_Click);
            // 
            // tmgroupBox1
            // 
            this.tmgroupBox1.Controls.Add(this.tmbtm_multiply);
            this.tmgroupBox1.Controls.Add(this.tmbtm_addition);
            this.tmgroupBox1.Controls.Add(this.tmbtm_subtraction);
            this.tmgroupBox1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tmgroupBox1.Location = new System.Drawing.Point(6, 132);
            this.tmgroupBox1.Name = "tmgroupBox1";
            this.tmgroupBox1.Size = new System.Drawing.Size(100, 359);
            this.tmgroupBox1.TabIndex = 5;
            this.tmgroupBox1.TabStop = false;
            this.tmgroupBox1.Text = "Operations on Matrices";
            // 
            // tmbtm_multiply
            // 
            this.tmbtm_multiply.BackColor = System.Drawing.Color.RosyBrown;
            this.tmbtm_multiply.Location = new System.Drawing.Point(0, 147);
            this.tmbtm_multiply.Name = "tmbtm_multiply";
            this.tmbtm_multiply.Size = new System.Drawing.Size(100, 50);
            this.tmbtm_multiply.TabIndex = 2;
            this.tmbtm_multiply.Text = "C = A * B";
            this.tmbtm_multiply.UseVisualStyleBackColor = false;
            // 
            // tmbtm_addition
            // 
            this.tmbtm_addition.BackColor = System.Drawing.Color.RosyBrown;
            this.tmbtm_addition.Location = new System.Drawing.Point(0, 35);
            this.tmbtm_addition.Name = "tmbtm_addition";
            this.tmbtm_addition.Size = new System.Drawing.Size(100, 50);
            this.tmbtm_addition.TabIndex = 0;
            this.tmbtm_addition.Text = "C = A + B";
            this.tmbtm_addition.UseVisualStyleBackColor = false;
            // 
            // tmbtm_subtraction
            // 
            this.tmbtm_subtraction.BackColor = System.Drawing.Color.RosyBrown;
            this.tmbtm_subtraction.Location = new System.Drawing.Point(0, 91);
            this.tmbtm_subtraction.Name = "tmbtm_subtraction";
            this.tmbtm_subtraction.Size = new System.Drawing.Size(100, 50);
            this.tmbtm_subtraction.TabIndex = 1;
            this.tmbtm_subtraction.Text = "C = A - B";
            this.tmbtm_subtraction.UseVisualStyleBackColor = false;
            // 
            // tmtextbox_number_of_columns
            // 
            this.tmtextbox_number_of_columns.BackColor = System.Drawing.Color.RosyBrown;
            this.tmtextbox_number_of_columns.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tmtextbox_number_of_columns.Location = new System.Drawing.Point(6, 74);
            this.tmtextbox_number_of_columns.Name = "tmtextbox_number_of_columns";
            this.tmtextbox_number_of_columns.Size = new System.Drawing.Size(100, 21);
            this.tmtextbox_number_of_columns.TabIndex = 3;
            // 
            // tmlabel3
            // 
            this.tmlabel3.AutoSize = true;
            this.tmlabel3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tmlabel3.Location = new System.Drawing.Point(6, 57);
            this.tmlabel3.Name = "tmlabel3";
            this.tmlabel3.Size = new System.Drawing.Size(116, 15);
            this.tmlabel3.TabIndex = 1;
            this.tmlabel3.Text = "Number of columns";
            // 
            // tmlabel2
            // 
            this.tmlabel2.AutoSize = true;
            this.tmlabel2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tmlabel2.Location = new System.Drawing.Point(6, 14);
            this.tmlabel2.Name = "tmlabel2";
            this.tmlabel2.Size = new System.Drawing.Size(95, 15);
            this.tmlabel2.TabIndex = 1;
            this.tmlabel2.Text = "Number of rows";
            // 
            // tmtextbox_number_of_rows
            // 
            this.tmtextbox_number_of_rows.BackColor = System.Drawing.Color.RosyBrown;
            this.tmtextbox_number_of_rows.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tmtextbox_number_of_rows.Location = new System.Drawing.Point(6, 34);
            this.tmtextbox_number_of_rows.Name = "tmtextbox_number_of_rows";
            this.tmtextbox_number_of_rows.Size = new System.Drawing.Size(100, 21);
            this.tmtextbox_number_of_rows.TabIndex = 7;
            // 
            // tmtab_page_complex_number
            // 
            this.tmtab_page_complex_number.BackColor = System.Drawing.Color.PaleGreen;
            this.tmtab_page_complex_number.Controls.Add(this.tmtextbox_result);
            this.tmtab_page_complex_number.Controls.Add(this.tmlabel50);
            this.tmtab_page_complex_number.Controls.Add(this.tmgroupbox_cn2);
            this.tmtab_page_complex_number.Controls.Add(this.tmgroupbox_cn);
            this.tmtab_page_complex_number.Controls.Add(this.tmlabel5);
            this.tmtab_page_complex_number.Location = new System.Drawing.Point(4, 24);
            this.tmtab_page_complex_number.Name = "tmtab_page_complex_number";
            this.tmtab_page_complex_number.Size = new System.Drawing.Size(1142, 972);
            this.tmtab_page_complex_number.TabIndex = 2;
            this.tmtab_page_complex_number.Text = "Operations on Complex Numbers";
            // 
            // tmtextbox_result
            // 
            this.tmtextbox_result.Location = new System.Drawing.Point(400, 190);
            this.tmtextbox_result.Name = "tmtextbox_result";
            this.tmtextbox_result.ReadOnly = true;
            this.tmtextbox_result.Size = new System.Drawing.Size(232, 21);
            this.tmtextbox_result.TabIndex = 18;
            // 
            // tmlabel50
            // 
            this.tmlabel50.AutoSize = true;
            this.tmlabel50.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tmlabel50.Location = new System.Drawing.Point(394, 135);
            this.tmlabel50.Name = "tmlabel50";
            this.tmlabel50.Size = new System.Drawing.Size(92, 32);
            this.tmlabel50.TabIndex = 17;
            this.tmlabel50.Text = "Result";
            // 
            // tmgroupbox_cn2
            // 
            this.tmgroupbox_cn2.Controls.Add(this.tmtextbox_real_a);
            this.tmgroupbox_cn2.Controls.Add(this.tmtextbox_imagine_a);
            this.tmgroupbox_cn2.Controls.Add(this.tmlabel_cn_4);
            this.tmgroupbox_cn2.Controls.Add(this.tmtextbox_real_b);
            this.tmgroupbox_cn2.Controls.Add(this.tmlabel_cn_3);
            this.tmgroupbox_cn2.Controls.Add(this.tmtextbox_imagine_b);
            this.tmgroupbox_cn2.Controls.Add(this.tmlabel_cn_2);
            this.tmgroupbox_cn2.Controls.Add(this.tmtextbox_real_c);
            this.tmgroupbox_cn2.Controls.Add(this.tmlabel_cn_1);
            this.tmgroupbox_cn2.Controls.Add(this.tmtextbox_imagine_c);
            this.tmgroupbox_cn2.Controls.Add(this.tmlabel_cn_6);
            this.tmgroupbox_cn2.Controls.Add(this.tmtextbox_real_e);
            this.tmgroupbox_cn2.Controls.Add(this.tmlabel_cn_5);
            this.tmgroupbox_cn2.Controls.Add(this.tmtextbox_imagine_e);
            this.tmgroupbox_cn2.Location = new System.Drawing.Point(9, 94);
            this.tmgroupbox_cn2.Name = "tmgroupbox_cn2";
            this.tmgroupbox_cn2.Size = new System.Drawing.Size(319, 185);
            this.tmgroupbox_cn2.TabIndex = 16;
            this.tmgroupbox_cn2.TabStop = false;
            // 
            // tmtextbox_real_a
            // 
            this.tmtextbox_real_a.Location = new System.Drawing.Point(56, 50);
            this.tmtextbox_real_a.Name = "tmtextbox_real_a";
            this.tmtextbox_real_a.Size = new System.Drawing.Size(100, 21);
            this.tmtextbox_real_a.TabIndex = 1;
            // 
            // tmtextbox_imagine_a
            // 
            this.tmtextbox_imagine_a.Location = new System.Drawing.Point(184, 50);
            this.tmtextbox_imagine_a.Name = "tmtextbox_imagine_a";
            this.tmtextbox_imagine_a.Size = new System.Drawing.Size(100, 21);
            this.tmtextbox_imagine_a.TabIndex = 2;
            // 
            // tmlabel_cn_4
            // 
            this.tmlabel_cn_4.Location = new System.Drawing.Point(0, 0);
            this.tmlabel_cn_4.Name = "tmlabel_cn_4";
            this.tmlabel_cn_4.Size = new System.Drawing.Size(100, 23);
            this.tmlabel_cn_4.TabIndex = 3;
            // 
            // tmtextbox_real_b
            // 
            this.tmtextbox_real_b.Location = new System.Drawing.Point(56, 80);
            this.tmtextbox_real_b.Name = "tmtextbox_real_b";
            this.tmtextbox_real_b.Size = new System.Drawing.Size(100, 21);
            this.tmtextbox_real_b.TabIndex = 3;
            // 
            // tmlabel_cn_3
            // 
            this.tmlabel_cn_3.AutoSize = true;
            this.tmlabel_cn_3.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tmlabel_cn_3.Location = new System.Drawing.Point(21, 110);
            this.tmlabel_cn_3.Name = "tmlabel_cn_3";
            this.tmlabel_cn_3.Size = new System.Drawing.Size(32, 17);
            this.tmlabel_cn_3.TabIndex = 13;
            this.tmlabel_cn_3.Text = "C =";
            // 
            // tmtextbox_imagine_b
            // 
            this.tmtextbox_imagine_b.Location = new System.Drawing.Point(184, 80);
            this.tmtextbox_imagine_b.Name = "tmtextbox_imagine_b";
            this.tmtextbox_imagine_b.Size = new System.Drawing.Size(100, 21);
            this.tmtextbox_imagine_b.TabIndex = 4;
            // 
            // tmlabel_cn_2
            // 
            this.tmlabel_cn_2.AutoSize = true;
            this.tmlabel_cn_2.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tmlabel_cn_2.Location = new System.Drawing.Point(22, 80);
            this.tmlabel_cn_2.Name = "tmlabel_cn_2";
            this.tmlabel_cn_2.Size = new System.Drawing.Size(31, 17);
            this.tmlabel_cn_2.TabIndex = 12;
            this.tmlabel_cn_2.Text = "B =";
            // 
            // tmtextbox_real_c
            // 
            this.tmtextbox_real_c.Location = new System.Drawing.Point(56, 110);
            this.tmtextbox_real_c.Name = "tmtextbox_real_c";
            this.tmtextbox_real_c.Size = new System.Drawing.Size(100, 21);
            this.tmtextbox_real_c.TabIndex = 5;
            // 
            // tmlabel_cn_1
            // 
            this.tmlabel_cn_1.Location = new System.Drawing.Point(0, 0);
            this.tmlabel_cn_1.Name = "tmlabel_cn_1";
            this.tmlabel_cn_1.Size = new System.Drawing.Size(100, 23);
            this.tmlabel_cn_1.TabIndex = 14;
            // 
            // tmtextbox_imagine_c
            // 
            this.tmtextbox_imagine_c.Location = new System.Drawing.Point(184, 110);
            this.tmtextbox_imagine_c.Name = "tmtextbox_imagine_c";
            this.tmtextbox_imagine_c.Size = new System.Drawing.Size(100, 21);
            this.tmtextbox_imagine_c.TabIndex = 6;
            // 
            // tmlabel_cn_6
            // 
            this.tmlabel_cn_6.AutoSize = true;
            this.tmlabel_cn_6.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tmlabel_cn_6.Location = new System.Drawing.Point(180, 20);
            this.tmlabel_cn_6.Name = "tmlabel_cn_6";
            this.tmlabel_cn_6.Size = new System.Drawing.Size(115, 17);
            this.tmlabel_cn_6.TabIndex = 10;
            this.tmlabel_cn_6.Text = "Imagine Number";
            // 
            // tmtextbox_real_e
            // 
            this.tmtextbox_real_e.Location = new System.Drawing.Point(56, 140);
            this.tmtextbox_real_e.Name = "tmtextbox_real_e";
            this.tmtextbox_real_e.Size = new System.Drawing.Size(100, 21);
            this.tmtextbox_real_e.TabIndex = 7;
            // 
            // tmlabel_cn_5
            // 
            this.tmlabel_cn_5.AutoSize = true;
            this.tmlabel_cn_5.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tmlabel_cn_5.Location = new System.Drawing.Point(52, 20);
            this.tmlabel_cn_5.Name = "tmlabel_cn_5";
            this.tmlabel_cn_5.Size = new System.Drawing.Size(94, 17);
            this.tmlabel_cn_5.TabIndex = 9;
            this.tmlabel_cn_5.Text = "Real Number";
            // 
            // tmtextbox_imagine_e
            // 
            this.tmtextbox_imagine_e.Location = new System.Drawing.Point(184, 140);
            this.tmtextbox_imagine_e.Name = "tmtextbox_imagine_e";
            this.tmtextbox_imagine_e.Size = new System.Drawing.Size(100, 21);
            this.tmtextbox_imagine_e.TabIndex = 8;
            // 
            // tmgroupbox_cn
            // 
            this.tmgroupbox_cn.Controls.Add(this.tmbtm_cn_add);
            this.tmgroupbox_cn.Location = new System.Drawing.Point(782, 94);
            this.tmgroupbox_cn.Name = "tmgroupbox_cn";
            this.tmgroupbox_cn.Size = new System.Drawing.Size(275, 316);
            this.tmgroupbox_cn.TabIndex = 15;
            this.tmgroupbox_cn.TabStop = false;
            this.tmgroupbox_cn.Text = "Operations on Complex Numbers";
            // 
            // tmbtm_cn_add
            // 
            this.tmbtm_cn_add.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tmbtm_cn_add.Location = new System.Drawing.Point(20, 25);
            this.tmbtm_cn_add.Name = "tmbtm_cn_add";
            this.tmbtm_cn_add.Size = new System.Drawing.Size(80, 50);
            this.tmbtm_cn_add.TabIndex = 0;
            this.tmbtm_cn_add.Text = "C = A + B";
            this.tmbtm_cn_add.UseVisualStyleBackColor = true;
            // 
            // tmlabel5
            // 
            this.tmlabel5.AutoSize = true;
            this.tmlabel5.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tmlabel5.Location = new System.Drawing.Point(394, 33);
            this.tmlabel5.Name = "tmlabel5";
            this.tmlabel5.Size = new System.Drawing.Size(397, 32);
            this.tmlabel5.TabIndex = 0;
            this.tmlabel5.Text = "Calculator of Complex Numbers";
            // 
            // tmmatrix_a_grid
            // 
            this.tmmatrix_a_grid.AllowUserToAddRows = false;
            this.tmmatrix_a_grid.AllowUserToDeleteRows = false;
            this.tmmatrix_a_grid.AllowUserToResizeRows = false;
            this.tmmatrix_a_grid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.tmmatrix_a_grid.BackgroundColor = System.Drawing.SystemColors.Control;
            this.tmmatrix_a_grid.ColumnHeadersVisible = false;
            this.tmmatrix_a_grid.GridColor = System.Drawing.SystemColors.ControlDarkDark;
            this.tmmatrix_a_grid.Location = new System.Drawing.Point(225, 30);
            this.tmmatrix_a_grid.Name = "tmmatrix_a_grid";
            this.tmmatrix_a_grid.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.tmmatrix_a_grid.Size = new System.Drawing.Size(500, 150);
            this.tmmatrix_a_grid.TabIndex = 8;
            // 
            // tmmatrix_b_grid
            // 
            this.tmmatrix_b_grid.AllowUserToAddRows = false;
            this.tmmatrix_b_grid.AllowUserToDeleteRows = false;
            this.tmmatrix_b_grid.AllowUserToResizeColumns = false;
            this.tmmatrix_b_grid.AllowUserToResizeRows = false;
            this.tmmatrix_b_grid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.tmmatrix_b_grid.BackgroundColor = System.Drawing.SystemColors.Control;
            this.tmmatrix_b_grid.Location = new System.Drawing.Point(225, 200);
            this.tmmatrix_b_grid.Name = "tmmatrix_b_grid";
            this.tmmatrix_b_grid.RowHeadersVisible = false;
            this.tmmatrix_b_grid.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.tmmatrix_b_grid.Size = new System.Drawing.Size(500, 150);
            this.tmmatrix_b_grid.TabIndex = 9;
            // 
            // tmmatrix_c_grid
            // 
            this.tmmatrix_c_grid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.tmmatrix_c_grid.BackgroundColor = System.Drawing.SystemColors.Control;
            this.tmmatrix_c_grid.ColumnHeadersVisible = false;
            this.tmmatrix_c_grid.Location = new System.Drawing.Point(225, 375);
            this.tmmatrix_c_grid.Name = "tmmatrix_c_grid";
            this.tmmatrix_c_grid.RowHeadersVisible = false;
            this.tmmatrix_c_grid.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.tmmatrix_c_grid.Size = new System.Drawing.Size(500, 150);
            this.tmmatrix_c_grid.TabIndex = 10;
            // 
            // tmerrorProvider
            // 
            this.tmerrorProvider.ContainerControl = this;
            // 
            // new_data_types
            // 
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1134, 961);
            this.Controls.Add(this.tmtabs);
            this.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.MaximizeBox = false;
            this.Name = "new_data_types";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "New data types : Matrixes and Complex Numbers";
            this.tmtabs.ResumeLayout(false);
            this.tmtab_page_cockpit.ResumeLayout(false);
            this.tmtab_page_cockpit.PerformLayout();
            this.tmtab_page_matrix.ResumeLayout(false);
            this.tmtab_page_matrix.PerformLayout();
            this.tmgroupBox2.ResumeLayout(false);
            this.tmgroupBox1.ResumeLayout(false);
            this.tmtab_page_complex_number.ResumeLayout(false);
            this.tmtab_page_complex_number.PerformLayout();
            this.tmgroupbox_cn2.ResumeLayout(false);
            this.tmgroupbox_cn2.PerformLayout();
            this.tmgroupbox_cn.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tmmatrix_a_grid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmmatrix_b_grid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmmatrix_c_grid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmerrorProvider)).EndInit();
            this.ResumeLayout(false);

        }

        private System.Windows.Forms.TabControl tmtabs;
        private System.Windows.Forms.TabPage tmtab_page_cockpit;
        private System.Windows.Forms.TabPage tmtab_page_matrix;
        private System.Windows.Forms.TabPage tmtab_page_complex_number;
        private System.Windows.Forms.Label tmcocpitlabel;
        private System.Windows.Forms.Label tmlabel2;
        private System.Windows.Forms.Label tmlabel3;
        private System.Windows.Forms.GroupBox tmgroupBox2;
        private System.Windows.Forms.Button tmbtm_generate_matrix_a_elements;
        private System.Windows.Forms.Button tmbtm_create_gridview_matrix_a;
        private System.Windows.Forms.GroupBox tmgroupBox1;
        private System.Windows.Forms.Button tmbtm_multiply;
        private System.Windows.Forms.Button tmbtm_subtraction;
        private System.Windows.Forms.Button tmbtm_addition;
        private System.Windows.Forms.Button tmbtm_accept_matrix_a_elements;
        private System.Windows.Forms.Button tmbtm_accept_matrix_b_elements;
        private System.Windows.Forms.Button tmbtm_generate_matrix_b_elements;
        private System.Windows.Forms.Button tmbtm_create_gridview_matrix_b;
        private System.Windows.Forms.Button tmbtm_reset;
        private System.Windows.Forms.DataGridView tmmatrix_a_grid;
        private System.Windows.Forms.DataGridView tmmatrix_b_grid;
        private System.Windows.Forms.DataGridView tmmatrix_c_grid;
        private TextBox tmtextbox_number_of_columns;
        private TextBox tmtextbox_number_of_rows;
        private Label tmlabel5;
        private Label tmlabel_cn_4;
        private Label tmlabel_cn_3;
        private Label tmlabel_cn_2;
        private Label tmlabel_cn_1;
        private Label tmlabel_cn_6;
        private Label tmlabel_cn_5;
        private TextBox tmtextbox_imagine_e;
        private TextBox tmtextbox_real_e;
        private TextBox tmtextbox_imagine_c;
        private TextBox tmtextbox_real_c;
        private TextBox tmtextbox_imagine_b;
        private TextBox tmtextbox_real_b;
        private TextBox tmtextbox_imagine_a;
        private TextBox tmtextbox_real_a;
        private GroupBox tmgroupbox_cn;
        private Button tmbtm_cn_add;
        private GroupBox tmgroupbox_cn2;
        private TextBox tmtextbox_result;
        private Label tmlabel50;
        private Matrix tma;
        private Matrix tmb;
        private ErrorProvider tmerrorProvider;
    }
}

