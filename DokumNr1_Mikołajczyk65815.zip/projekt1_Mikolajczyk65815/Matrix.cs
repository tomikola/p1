﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project1_Mikolajczyk65815
{
    internal class Matrix
    {
        private float[,] tmmatrix;

        public Matrix(ushort number_of_rows, ushort number_of_columns)
        {
            tmmatrix = new float[number_of_rows, number_of_columns];
        }

        public float this[ushort number_of_rows, ushort number_of_columns]
        {
            set
            {
                if (
                    (number_of_rows >= 0) && (number_of_rows < tmmatrix.GetLength(0))
                    && (number_of_columns >= 0) && (number_of_columns < tmmatrix.GetLength(1))
                    )

                    tmmatrix[number_of_rows, number_of_columns] = value;

                else
                    throw new IndexOutOfRangeException("Error; Value out of Indexes Range of the Matrix");



            }

            get
            {
                if (
                    (number_of_rows >= 0) && (number_of_rows < tmmatrix.GetLength(0))
                    && (number_of_columns >= 0) && (number_of_columns < tmmatrix.GetLength(1))
                    )

                    return tmmatrix[number_of_rows, number_of_columns];
                else
                    throw new IndexOutOfRangeException("Error; Value out of Indexes Range of the Matrix");
            }
        }
        public ushort number_of_rows
        {
            get
            {
                return (ushort)tmmatrix.GetLength(0);
            }
        }
        public ushort number_of_columns
        {
            get
            {
                return (ushort)tmmatrix.GetLength(1);
            }
        }

        public static Matrix operator +(Matrix a, Matrix b)
        {
            if (a.number_of_rows != b.number_of_rows || a.number_of_columns != b.number_of_columns)
                throw new ArgumentException("Error: Matrixes do not have the same size");
            Matrix c = new Matrix(a.number_of_rows, a.number_of_columns);
            for (ushort tmi = 0; tmi < a.number_of_rows; tmi++)
            {
                for (ushort tmj = 0; tmj < b.number_of_columns; tmj++)
                {
                    c.tmmatrix[tmi, tmj] = a.tmmatrix[tmi, tmj] + b.tmmatrix[tmi, tmj];
                }
            }
            return c;
        }
        public static Matrix operator -(Matrix a, Matrix b)
        {
            if (a.number_of_rows != b.number_of_rows || a.number_of_columns != b.number_of_columns)
                throw new ArgumentException("Error: Matrixes do not have the same size");
            Matrix c = new Matrix(a.number_of_rows, a.number_of_columns);
            for (ushort tmi = 0; tmi < a.number_of_rows; tmi++)
            {
                for (ushort tmj = 0; tmj < b.number_of_columns; tmj++)
                {
                    c.tmmatrix[tmi, tmj] = a.tmmatrix[tmi, tmj] - b.tmmatrix[tmi, tmj];
                }
            }
            return c;
        }
        public static Matrix operator *(Matrix a, Matrix b)
        {
            if (a.number_of_columns != b.number_of_rows)
                throw new ArgumentException("Error: Matrixes do not have correct size. 1st Matrix Number of Columns should be equal to 2nd Matrix Number of Rows");
            Matrix c = new Matrix(a.number_of_rows, b.number_of_columns);
            for (ushort tmi = 0; tmi < a.number_of_rows; tmi++)
            {
                for (ushort tmj = 0; tmj < b.number_of_columns; tmj++)
                {
                    c.tmmatrix[tmi, tmj] = 0;
                    for (ushort tmk = 0; tmk < a.number_of_columns; tmk++)
                    {
                        c.tmmatrix[tmi, tmj] += a.tmmatrix[tmi, tmk] * b.tmmatrix[tmk, tmj];
                    }
                }
            }
            return c;
        }

        public static Matrix operator *(Matrix a, float val)
        {
            Matrix c = new Matrix(a.number_of_rows, a.number_of_columns);
            for (ushort i = 0; i < a.number_of_rows; i++)
            {
                for (ushort tmj = 0; tmj < a.number_of_columns; tmj++)
                {
                    c.tmmatrix[i, tmj] = a[i, tmj] * val;
                }
            }
            return c;
        }

        public void fill_matrix()
        {
            Random rand = new Random();
            for (ushort i = 0; i < tmmatrix.GetLength(0); i++)
            {
                for (ushort j = 0; j < tmmatrix.GetLength(1); j++)
                {

                    tmmatrix[i, j] = (float)(rand.NextDouble() * 20.0 - 10.0);
                }
            }
        }
        public void fill_matrix_zeroes()
        {
            for (ushort i = 0; i < tmmatrix.GetLength(0); i++)
            {
                for (ushort j = 0; j < tmmatrix.GetLength(1); j++)
                {
                    tmmatrix[i, j] = 0;
                }
            }
        }
        public DataTable ToDataTable()
        {
            DataTable tmdt = new DataTable();
            for (int j = 0; j < tmmatrix.GetLength(1); j++)
            {
                tmdt.Columns.Add(j.ToString(), typeof(float));
            }
            for (int i = 0; i < tmmatrix.GetLength(0); i++)
            {
                DataRow row = tmdt.NewRow();
                for (int j = 0; j < tmmatrix.GetLength(1); j++)
                {
                    row[j] = tmmatrix[i, j];
                }
                tmdt.Rows.Add(row);
            }
            return tmdt;
        }

    }
}
