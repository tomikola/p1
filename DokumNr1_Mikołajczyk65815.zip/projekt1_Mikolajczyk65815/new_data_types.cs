﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project1_Mikolajczyk65815
{
    public partial class new_data_types : Form
    {
        bool[] tmtab_page_activity_status = { true, true, true };
        public new_data_types()
        {
            InitializeComponent();
        }
        private void tmtabControl_Selecting(object sender, TabControlCancelEventArgs e)
        {
            if ((e.TabPage == tmtabs.TabPages[0])
                && (tmtab_page_activity_status[0] == true))
            {
                tmtab_page_activity_status[1] = true;
                tmtab_page_activity_status[2] = true;
                tmtabs.SelectedTab = tmtab_page_cockpit;

            }
            else
            {
                if ((e.TabPage == tmtabs.TabPages[1])
                    && (tmtab_page_activity_status[1] == true))
                {
                    tmtab_page_activity_status[2] = false;
                    tmtabs.SelectedTab = tmtab_page_matrix;

                }
                else
                {
                    if ((e.TabPage == tmtabs.TabPages[2])
                        && (tmtab_page_activity_status[2] == true))
                    {
                        tmtab_page_activity_status[1] = false;
                        tmtabs.SelectedTab = tmtab_page_complex_number;

                    }
                    else
                    {
                        e.Cancel = true;
                    }
                }
            }
        }

        private void tmbtm_create_gridview_matrix_a_Click(object sender, EventArgs e)
        {
            this.tmerrorProvider.Dispose();

            if (this.tmtab_page_matrix.Controls.Contains(this.tmmatrix_a_grid) == false)
            {
                if ((ushort.TryParse(this.tmtextbox_number_of_rows.Text, out ushort result) == false)
                    || (ushort.TryParse(this.tmtextbox_number_of_columns.Text, out ushort result2) == false)
                    || (this.tmtextbox_number_of_rows.Text.Equals(""))
                    || (this.tmtextbox_number_of_rows.Text.Equals("")))
                {
                   
                    this.tmerrorProvider.SetError(tmbtm_create_gridview_matrix_a, "Empty Number of Rows or Number of Columns");
                }
                else
                {
                    
                    this.tma = new Matrix(ushort.Parse(tmtextbox_number_of_rows.Text), ushort.Parse(tmtextbox_number_of_columns.Text));
                    DataTable tmdt = this.tma.ToDataTable();
                    Console.WriteLine($"DataTable Rows: {tmdt.Rows.Count}, Columns: {tmdt.Columns.Count}");
                    this.tmmatrix_a_grid.DataSource = tmdt;

                    this.tmtab_page_matrix.Controls.Add(this.tmmatrix_a_grid);
                    ((System.ComponentModel.ISupportInitialize)(this.tmmatrix_a_grid)).EndInit();
                    for (ushort row = 0; row < this.tmmatrix_a_grid.Rows.Count; row++)
                    {
                        for (ushort col = 0; col < this.tmmatrix_a_grid.Columns.Count; col++)
                        {


                            Console.WriteLine(tmmatrix_a_grid.Rows[row].Cells[col].Value.ToString());
                        }
                    }

                }
            }
        }

        private void tmbtm_generate_matrix_a_elements_Click(object sender, EventArgs e)
        {
            this.tmerrorProvider.Dispose();
            if (this.tmtab_page_matrix.Controls.Contains(this.tmmatrix_a_grid) == false)
            {
                this.tmerrorProvider.SetError(this.tmbtm_generate_matrix_a_elements, "You must generate data grid for matrix A before you use this button");
            }
            else
            {

                this.tma.fill_matrix();
                DataTable tmdt = tma.ToDataTable();
                this.tmmatrix_a_grid.DataSource = tmdt;
            }

        }

        private void tmbtm_accept_matrix_a_elements_Click(object sender, EventArgs e)
        {
            this.tmerrorProvider.Dispose();
            if (this.tmtab_page_matrix.Controls.Contains(this.tmmatrix_a_grid) == false)
            {
                this.tmerrorProvider.SetError(this.tmbtm_accept_matrix_a_elements, "You must generate data grid for matrix A before you use this button");
            }
            else
            {
                for (ushort row = 0; row < this.tmmatrix_a_grid.Rows.Count; row++)
                {
                    for (ushort col = 0; col < this.tmmatrix_a_grid.Columns.Count; col++)
                    {
                        tma[row, col] = float.Parse(tmmatrix_a_grid.Rows[row].Cells[col].Value.ToString());
                    }
                }

                this.tmmatrix_a_grid.ReadOnly = true;
            }


        }

        private void tmbtm_create_gridview_matrix_b_Click(object sender, EventArgs e)
        {
            this.tmerrorProvider.Dispose();

            if (this.tmtab_page_matrix.Controls.Contains(this.tmmatrix_b_grid) == false)
            {
                if ((ushort.TryParse(this.tmtextbox_number_of_rows.Text, out ushort result) == false)
                    || (ushort.TryParse(this.tmtextbox_number_of_columns.Text, out ushort result2) == false)
                    || (this.tmtextbox_number_of_rows.Text.Equals(""))
                    || (this.tmtextbox_number_of_rows.Text.Equals("")))
                {

                    this.tmerrorProvider.SetError(tmbtm_create_gridview_matrix_b, "Empty Number of Rows or Number of Columns");
                }
                else
                {

                    this.tmb = new Matrix(ushort.Parse(tmtextbox_number_of_rows.Text), ushort.Parse(tmtextbox_number_of_columns.Text));
                    DataTable tmdt = this.tma.ToDataTable();
                    Console.WriteLine($"DataTable Rows: {tmdt.Rows.Count}, Columns: {tmdt.Columns.Count}");
                    this.tmmatrix_b_grid.DataSource = tmdt;

                    this.tmtab_page_matrix.Controls.Add(this.tmmatrix_b_grid);
                    ((System.ComponentModel.ISupportInitialize)(this.tmmatrix_b_grid)).EndInit();



                }
            }
        }

        private void tmbtm_generate_matrix_b_elements_Click(object sender, EventArgs e)
        {

        }

        private void tmbtm_accept_matrix_b_elements_Click(object sender, EventArgs e)
        {

        }
    }

}
